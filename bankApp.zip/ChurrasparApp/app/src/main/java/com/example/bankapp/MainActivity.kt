package com.example.bankapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.bankapp.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val creditoInput: EditText = findViewById(R.id.creditoInput)
        val debitoInput: EditText = findViewById(R.id.debitoInput)
        val descricaoInput: EditText = findViewById(R.id.descricaoInput)
        val btnCalcular: Button = findViewById(R.id.btnCalcular)
        val btnLimpar: Button = findViewById(R.id.btnLimpar)

        val debitoTextView: TextView = findViewById(R.id.debitoTextView)
        val creditoTextView: TextView = findViewById(R.id.creditoTextView)
        val descricaoTextView: TextView = findViewById(R.id.descricaoTextView)
        val valorTextView: TextView = findViewById(R.id.valorTextView)

        btnCalcular.setOnClickListener {
            val homens = creditoInput.text.toString().toIntOrNull() ?: 0
            val mulheres = debitoInput.text.toString().toIntOrNull() ?: 0
            val descricao = descricaoInput.text.toString().toIntOrNull() ?:0

            val valor = creditoInput + debitoInput

            valorTextView = "$valor total"
        }

        btnLimpar.setOnClickListener {
            creditoInput.text.clear()
            debitoInput.text.clear()
            descricaoInput.text.clear()

        }
    }
}
